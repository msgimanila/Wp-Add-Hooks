<?php
/*
   Plugin Name: HASLOO iPhone Theme
   Plugin URI: http://hasloo.com
   Description: A plugin which formats your site with a mobile theme for the Apple <a href="http://www.apple.com/iphone/">iPhone</a> / <a href="http://www.apple.com/ipodtouch/">iPod touch</a>, <a href="http://www.android.com/">Google Android</a>, <a href="http://www.palm.com/us/products/phones/pre/">Palm Pre</a> and other touch-based smartphones.
	Author: Hasloo.com
	Version: 1.9.13
	Author URI: http://www.hasloo.com
   
	# Thanks to ContentRobot and the iWPhone theme/plugin
	# which the detection feature of the plugin was based on.
	# (http://iwphone.contentrobot.com/)
	
	# Also thanks to Henrik Urlund, who's "Prowl Me" plugin inspired
	# the Push notification additions.
	# (http://codework.dk/referencer/wp-plugins/prowl-me/)
	
	# All Admin and theme design / CSS is Copyright (c) 2007-2010
	# Duane Storey & Dale Mugford of BraveNewCode Inc.
	#
	# 'hasloo' is a trademark of BraveNewCode Inc., 
	# and may not be used in conjuction with the redistribution, advertisment, 
	# sale or other public use of this software without permission.
	
	# The code in this plugin is free software; you can redistribute the code aspects of
	# the plugin and/or modify the code under the terms of the GNU Lesser General
	# Public License as published by the Free Software Foundation; either
	# version 2.1 of the License, or (at your option) any later version.
	
	# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
	# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
	# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
	# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
	# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
	# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
	#
	# See the GNU lesser General Public License for more details.
*/

global $bnc_hasloo_version;
$bnc_hasloo_version = '1.9.13';

require_once( 'include/plugin.php' );
require_once( 'include/compat.php' );

define( 'HASLOO_PROWL_APPNAME', 'hasloo');

//The hasloo Settings Defaults
global $hasloo_defaults;
$hasloo_defaults = array(
	'header-title' => get_bloginfo('name'),
	'main_title' => 'Default.png',
	'enable-post-excerpts' => true,
	'enable-page-coms' => false,
	'enable-cats-button' => true,
	'enable-tags-button' => true,
	'enable-search-button' => true,
	'enable-login-button' => false,
	'enable-gravatars' => true,
	'enable-main-home' => true,
	'enable-main-rss' => true,
	'enable-main-name' => true,
	'enable-main-tags' => true,
	'enable-main-categories' => true,
	'enable-main-email' => true,
	'enable-truncated-titles' => true,
	'prowl-api' => '',
	'enable-prowl-comments-button' => false,
	'enable-prowl-users-button' => false,
	'enable-prowl-message-button' => false,
	'header-background-color' => '000000',
	'header-border-color' => '333333',
	'header-text-color' => 'eeeeee',
	'link-color' => '006bb3',
	'post-cal-thumb' =>'calendar-icons',
	'h2-font' =>'Helvetica Neue',
	'style-text-justify' => 'full-justified',
	'style-background' => 'classic-hasloo-bg',
	'style-icon' => 'glossy-icon',
	'enable-regular-default' => false,
	'excluded-cat-ids' => '',
	'home-page' => 0,
	'enable-exclusive' => false,
	'sort-order' => 'name',
	'adsense-id' => '',
	'statistics' => '',
	'adsense-channel' => '',
	'custom-user-agents' => array(),
	'enable-show-tweets' => false,
	'enable-gigpress-button' => false,
	'enable-flat-icon' => false
);

function hasloo_supercache_strings( $user_agents ) {
	$hasloo_user_agents = bnc_hasloo_get_user_agents();
	
	foreach( $hasloo_user_agents as $check_user_agent ) {
		if ( !in_array( $check_user_agent, $user_agents ) ) {
			$user_agents[] = $check_user_agent;	
		}
	}
	
	return $user_agents;
}

function hasloo_plugins_loaded() {
	// Check for WP Super Cache and (hopefully) add support for it
	if ( function_exists( 'wpsc_update_htaccess' ) ) {
		add_filter( 'cached_mobile_browsers', 'hasloo_supercache_strings' );
	}
}

add_action( 'plugins_loaded', 'hasloo_plugins_loaded' );

function hasloo_get_plugin_dir_name() {
	global $hasloo_plugin_dir_name;
	return $hasloo_plugin_dir_name;
}

function hasloo_delete_icon( $icon ) {
	if ( !current_user_can( 'upload_files' ) ) {
		// don't allow users to delete who don't have access to upload (security feature)
		return;	
	}
			
	$dir = explode( 'hasloo', $icon );
	$loc = compat_get_upload_dir() . "/hasloo/" . ltrim( $dir[1], '/' );

	unlink( $loc );
}

function hasloo_init() {	
	if ( isset( $_GET['delete_icon'] ) ) {
		hasloo_delete_icon( $_GET['delete_icon'] );
		header( 'Location: ' . get_bloginfo('wpurl') . '/wp-admin/options-general.php?page=hasloo/hasloo.php#available_icons' );
		die;
	}
	
	// 	

}

function hasloo_include_adsense() {
	global $hasloo_plugin;
	$settings = bnc_hasloo_get_settings();
	if ( bnc_is_iphone() && $hasloo_plugin->desired_view == 'mobile' && isset( $settings['adsense-id'] ) && strlen( $settings['adsense-id'] ) && is_single() ) {
		global $hasloo_settings;
		$hasloo_settings = $settings;
		
		include( 'include/adsense-new.php' );
	}
}

function hasloo_content_filter( $content ) {
	global $hasloo_plugin;
	$settings = bnc_hasloo_get_settings();
	if ( bnc_is_iphone() && $hasloo_plugin->desired_view == 'mobile' && isset($settings['adsense-id']) && strlen($settings['adsense-id']) && is_single() ) {
		global $hasloo_settings;
		$hasloo_settings = $settings;
		
		ob_start();
		include( 'include/adsense-new.php' );
		$ad_contents = ob_get_contents();
		ob_end_clean();
		
		return  '<div class="hasloo-adsense-ad">' . $ad_contents . '</div>' . $content;	
	} else {
		return $content;
	}
}

	add_filter('init', 'hasloo_init');

// Version number for the admin header, footer
function hasloo($before = '', $after = '') {
	global $bnc_hasloo_version;
	echo $before . 'hasloo ' . $bnc_hasloo_version . $after;
}

// Stop '0' Comment Counts
function wp_touch_get_comment_count() {
	global $wpdb;
	global $post;
	
	$result = $wpdb->get_row( $wpdb->prepare( "SELECT count(*) as c FROM {$wpdb->comments} WHERE comment_type = '' AND comment_approved = 1 AND comment_post_ID = %d", $post->ID ) );
	if ( $result ) {
		return $result->c;
	} else {
		return 0;	
	}
}
	
// hasloo WP Thumbnail Support
	if ( function_exists( 'add_theme_support' ) ) { // Added in 2.9
		add_theme_support( 'post-thumbnails'); // Add it for posts
}


//Add a link to 'Settings' on the plugin listings page
function hasloo_settings_link( $links, $file ) {
 	if( $file == 'hasloo/hasloo.php' && function_exists( "admin_url" ) ) {
		$settings_link = '<a href="' . admin_url( 'options-general.php?page=hasloo/hasloo.php' ) . '">' . __('Settings') . '</a>';
		array_unshift( $links, $settings_link ); // before the other links
	}
	return $links;
}
 
// WP Admin stylesheets & javascript
function hasloo_admin_files() {		
	if ( isset( $_GET['page'] ) && $_GET['page'] == 'hasloo/hasloo.php' ) {
		echo "<link rel='stylesheet' type='text/css' href='" . compat_get_plugin_url( 'hasloo' ) . "/admin-css/hasloo-admin.css' />\n";
		echo "<link rel='stylesheet' type='text/css' href='" . compat_get_plugin_url( 'hasloo' ) . "/admin-css/bnc-global.css' />\n";
		echo "<link rel='stylesheet' type='text/css' href='" . compat_get_plugin_url( 'hasloo' ) . "/admin-css/bnc-compressed-global.css' />\n";
		echo "<script type='text/javascript' src='" . compat_get_plugin_url( 'hasloo' ) . "/js/ajax_upload.js'></script>\n";
		echo "<script type='text/javascript' src='" . compat_get_plugin_url( 'hasloo' ) . "/js/colorpicker_1.4.js'></script>\n";
		echo "<script type='text/javascript' src='" . compat_get_plugin_url( 'hasloo' ) . "/js/fancybox_1.2.5.js'></script>\n";
		echo "<script type='text/javascript' src='" . compat_get_plugin_url( 'hasloo' ) . "/js/jquery-ui.js'></script>\n";
		echo "<script type='text/javascript' src='" . compat_get_plugin_url( 'hasloo' ) . "/js/admin_1.9.js'></script>\n";
		echo "<script type='text/javascript' src='" . get_bloginfo( "home" ) . "/?hasloo-ajax=js'></script>";
	}

}

function hasloo_ajax_handler() {	
	if ( isset( $_GET['hasloo-ajax'] ) ) {
		switch( $_GET['hasloo-ajax'] ) {
			case 'js':
				header( 'Content-type: text/javascript' );
				$url = rtrim( get_bloginfo('home'), '/' ) . '/';
				echo "var haslooBlogUrl = '" . $url . "';";
				break;		
			case 'news':
				include( WP_PLUGIN_DIR . '/hasloo/ajax/news.php' );	
				break;
//			case 'support':
//				include( WP_PLUGIN_DIR . '/hasloo/ajax/support.php' );
//				break;
			default:
				break;
		}	
		die;
	}	
}

add_action( 'init', 'hasloo_ajax_handler' );

function bnc_hasloo_get_user_agents() {
	$useragents = array(		
		"iPhone",  				 // Apple iPhone
		"iPod", 					 // Apple iPod touch
		"Android", 			 // 1.5+ Android
		"dream", 				 // Pre 1.5 Android
		"CUPCAKE", 			 // 1.5+ Android
		"BlackBerry9500",	 // Storm
		"BlackBerry9530",	 // Storm
		"webOS",				 // Palm Pre Experimental
		"incognito", 			 // Other iPhone browser
		"webmate" 			 // Other iPhone browser
	);
	
	$settings = bnc_hasloo_get_settings();
	if ( isset( $settings['custom-user-agents'] ) ) {
		foreach( $settings['custom-user-agents'] as $agent ) {
			if ( !strlen( $agent ) ) continue;
			
			$useragents[] = $agent;	
		}	
	}
	
	asort( $useragents );

	// hasloo User Agent Filter
	$useragents = apply_filters( 'hasloo_user_agents', $useragents );
	
	return $useragents;
}

function bnc_hasloo_is_prowl_key_valid() {
	require_once( 'include/class.prowl.php' );		
		
	$settings = bnc_hasloo_get_settings();
				
	if ( isset( $settings['prowl-api'] ) ) {
		$api_key = $settings['prowl-api'];
			
		$prowl = new Prowl( $api_key, hasloo_PROWL_APPNAME );	
		$verify = $prowl->verify();
		return ( $verify === true );
	}
	
	return false;
}
  
class haslooPlugin {
	var $applemobile;
	var $desired_view;
	var $output_started;
	var $prowl_output;
	var $prowl_success;
		
	function haslooPlugin() {
		$this->output_started = false;
		$this->applemobile = false;
		$this->prowl_output = false;
		$this->prowl_success = false;

		// Don't change the template directory when in the admin panel
		add_action( 'plugins_loaded', array(&$this, 'detectAppleMobile') );
		if ( strpos( $_SERVER['REQUEST_URI'], '/wp-admin' ) === false ) {
			add_filter( 'stylesheet', array(&$this, 'get_stylesheet') );
			add_filter( 'theme_root', array(&$this, 'theme_root') );
			add_filter( 'theme_root_uri', array(&$this, 'theme_root_uri') );
			add_filter( 'template', array(&$this, 'get_template') );	
		}			
		
		add_filter( 'init', array(&$this, 'bnc_filter_iphone') );
		add_filter( 'wp', array(&$this, 'bnc_do_redirect') );
		add_filter( 'wp_head', array(&$this, 'bnc_head') );
		add_filter( 'query_vars', array( &$this, 'hasloo_query_vars' ) );
		add_filter( 'parse_request', array( &$this, 'hasloo_parse_request' ) );
		add_action( 'comment_post', array( &$this, 'hasloo_handle_new_comment' ) );
		add_action( 'user_register', array( &$this, 'hasloo_handle_new_user' ) );
		
		$this->detectAppleMobile();
	}
	
	function hasloo_cleanup_growl( $msg ) {
		$msg = str_replace("\r\n","\n", $msg);
		$msg = str_replace("\r","\n", $msg);
		return $msg;	
	}
	
	function hasloo_send_prowl_message( $title, $message ) {
		require_once( 'include/class.prowl.php' );		
		
		$settings = bnc_hasloo_get_settings();
				
		if ( isset( $settings['prowl-api'] ) ) {
			$api_key = $settings['prowl-api'];
			
			$prowl = new Prowl( $api_key, $settings['header-title'] );
				
			$this->prowl_output = true;
			$result = $prowl->add( 	1, $title, $this->hasloo_cleanup_growl( stripslashes( $message ) ) );	
			
			if ( $result ) {
				$this->prowl_success = true;
			} else {				
				$this->prowl_success = false;
			}		
		} else {
			return false;	
		}
	}
	
	function hasloo_handle_new_comment( $comment_id, $approval_status = '1' ) {
		$settings = bnc_hasloo_get_settings();
		
		if ( $approval_status != 'spam' 
		&& isset( $settings['prowl-api'] ) 
		&& isset( $settings['enable-prowl-comments-button'])
		&& $settings['enable-prowl-comments-button'] == 1 ) {
			
			$api_key = $settings['prowl-api'];
			
			require_once( 'include/class.prowl.php' );
			$comment = get_comment( $comment_id );
			$prowl = new Prowl( $api_key, $settings['header-title'] );
			
			if ( $comment->comment_type != 'spam' && $comment->comment_approved != 'spam' ) {
				if ( $comment->comment_type == 'trackback' || $comment->comment_type == 'pingback' ) {
					$result = $prowl->add( 	1, 
						__( "New Ping/Trackback", "hasloo" ),
						'From: '. $this->hasloo_cleanup_growl( stripslashes( $comment->comment_author ) ) . 
						"\nPost: ". $this->hasloo_cleanup_growl( stripslashes( $comment->comment_content ) ) 
					);			
			 	} else {
					$result = $prowl->add( 	1, 
						__( "New Comment", "hasloo" ),
						'Name: '. $this->hasloo_cleanup_growl( stripslashes( $comment->comment_author ) ) . 
						"\nE-Mail: ". $this->hasloo_cleanup_growl( stripslashes( $comment->comment_author_email ) ) .
						"\nComment: ". $this->hasloo_cleanup_growl( stripslashes( $comment->comment_content ) )
					);		 
			 	}
			}
		 }

	}
	

	function hasloo_handle_new_user( $user_id ) {
		$settings = bnc_hasloo_get_settings();
		
		if ( isset( $settings['prowl-api'] ) 
		&& isset( $settings['enable-prowl-users-button'] ) 
		&& $settings['enable-prowl-users-button'] == 1 ) {

			global $wpdb;			
			$api_key = $settings['prowl-api'];
			require_once( 'include/class.prowl.php' );
			global $table_prefix;
			$sql = $wpdb->prepare( "SELECT * from " . $table_prefix . "users WHERE ID = %d", $user_id );
			$user = $wpdb->get_row( $sql );
			
			if ( $user ) {
				$prowl = new Prowl( $api_key, $settings['header-title'] );	
				$result = $prowl->add( 	1, 
					__( "User Registration", "hasloo" ),
					'Name: '. $this->hasloo_cleanup_growl( stripslashes( $user->user_login ) ) . 
					"\nE-Mail: ". $this->hasloo_cleanup_growl( stripslashes( $user->user_email ) )
				);			
			}
		}
	}

	function hasloo_query_vars( $vars ) {
		$vars[] = "hasloo";
		return $vars;
	}
	
	function hasloo_parse_request( $wp ) {
		if  (array_key_exists( "hasloo", $wp->query_vars ) ) {
			switch ( $wp->query_vars["hasloo"] ) {
				case "upload":
					include( 'ajax/file_upload.php' );	
					break;
			}
			exit;
		}	
	}

	function bnc_head() {
		if ( $this->applemobile && $this->desired_view == 'normal' ) {
			echo "<link rel='stylesheet' type='text/css' href='" . compat_get_plugin_url( 'hasloo' ) . "/themes/core/core-css/hasloo-switch-link.css'></link>\n";
			echo "<meta name=\"viewport\" content=\"width=device-width,initial-scale=0,user-scalable=yes\" /> \n";
		}		
	}

	function bnc_do_redirect() {
	   global $post;
				
		// check for hasloo prowl direct messages	
		$nonce = '';
		if ( isset( $_POST['_nonce'] ) ) {
			$nonce = $_POST['_nonce'];	
		}
			
		if ( isset( $_POST['hasloo-prowl-message'] ) && wp_verify_nonce( $nonce, 'hasloo-prowl' )  ) {
			$name = $_POST['prowl-msg-name'];
			$email = $_POST['prowl-msg-email'];
			$msg = $_POST['prowl-msg-message'];
			
			$title = __( "Direct Message", "hasloo" );
			$prowl_message = 'From: '. $this->hasloo_cleanup_growl( $name ) . 
				"\nE-Mail: ". $this->hasloo_cleanup_growl( $email ) .
				"\nMessage: ". $this->hasloo_cleanup_growl( $msg );
				"\nIP: " . $_SERVER["REMOTE_ADDR"] .
				
			$this->hasloo_send_prowl_message( $title, $prowl_message );
		}		   
	   
	   if ( $this->applemobile && $this->desired_view == 'mobile' ) {
			$version = (float)get_bloginfo('version');
			$is_front = 0;
			$is_front = (is_front_page() && (bnc_get_selected_home_page() > 0));

			if ( $is_front ) {
	    	     $url = get_permalink( bnc_get_selected_home_page() );
	        	 header('Location: ' . $url);
	         	die;
	   	     }
	   }
	}

	function bnc_filter_iphone() {	
		$key = 'hasloo_switch_cookie';
		
	   if (isset($_GET['theme_view'])) {
	  		if ($_GET['theme_view'] == 'mobile') {
				setcookie($key, 'mobile', 0); 
			} elseif ($_GET['theme_view'] == 'normal') {
				setcookie($key, 'normal', 0);
			}
			
			$redirect_location = get_bloginfo( 'siteurl' );
// fix by cybrstudd
			if ( isset( $_GET['hasloo_redirect'] ) ) {
				$protocol = ($_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';
				$redirect_location = $protocol . $_GET['hasloo_redirect'];
			}
			
			header( 'Location: ' . $redirect_location );
			die;
		}

		$settings = bnc_hasloo_get_settings();
		if (isset($_COOKIE[$key])) {
			$this->desired_view = $_COOKIE[$key];
		} else {
			if ( $settings['enable-regular-default'] ) {
				$this->desired_view = 'normal';
			} else {
		  		$this->desired_view = 'mobile';
			}
		}		
	}
	
	function detectAppleMobile($query = '') {
		$container = $_SERVER['HTTP_USER_AGENT'];
		// The below prints out the user agent array. Uncomment to see it shown on the page.
		// print_r($container); 
		$this->applemobile = false;
		$useragents = bnc_hasloo_get_user_agents();
		$devfile =  compat_get_plugin_dir( 'hasloo' ) . '/include/developer.mode';
		foreach ( $useragents as $useragent ) {
			if ( preg_match( "#$useragent#i", $container ) || file_exists( $devfile ) ) {
				$this->applemobile = true;
			} 	
		}
	}

	function get_stylesheet( $stylesheet ) {
		if ($this->applemobile && $this->desired_view == 'mobile') {
			return 'default';
		} else {
			return $stylesheet;
		}
	}
		  
	function get_template( $template ) {
		$this->bnc_filter_iphone();
		if ($this->applemobile && $this->desired_view === 'mobile') {
			return 'default';
		} else {	   
			return $template;
		}
	}
		  
	function get_template_directory( $value ) {
		$theme_root = compat_get_plugin_dir( 'hasloo' );
		if ($this->applemobile && $this->desired_view === 'mobile') {
				return $theme_root . '/themes';
		} else {
				return $value;
		}
	}
		  
	function theme_root( $path ) {
		$theme_root = compat_get_plugin_dir( 'hasloo' );
		if ($this->applemobile && $this->desired_view === 'mobile') {
			return $theme_root . '/themes';
		} else {
			return $path;
		}
	}
		  
	function theme_root_uri( $url ) {
		if ($this->applemobile && $this->desired_view === 'mobile') {
			$dir = compat_get_plugin_url( 'hasloo' ) . "/themes";
			return $dir;
		} else {
			return $url;
		}
	}
}
  
global $hasloo_plugin;
$hasloo_plugin = new haslooPlugin();

function bnc_hasloo_is_mobile() {
	global $hasloo_plugin;
	
	return ( $hasloo_plugin->applemobile && $hasloo_plugin->desired_view == 'mobile' );	
}

//Thanks to edyoshi:
function bnc_is_iphone() {
	global $hasloo_plugin;
	$hasloo_plugin->bnc_filter_iphone();
	return $hasloo_plugin->applemobile;
}
  
// The Automatic Footer Template Switch Code (into "wp_footer()" in regular theme's footer.php)
function hasloo_switch() {
	global $hasloo_plugin;
	if ( bnc_is_iphone() && $hasloo_plugin->desired_view == 'normal' ) {
		echo '<div id="hasloo-switch-link">';
		_e( "Mobile Theme", "hasloo" ); 
		echo "<a onclick=\"document.getElementById('switch-on').style.display='block';document.getElementById('switch-off').style.display='none';\" href=\"" . get_bloginfo('siteurl') . "/?theme_view=mobile&hasloo_redirect=" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"] . "\"><img id=\"switch-on\" src=\"" . compat_get_plugin_url( 'hasloo' ) . "/themes/core/core-images/on.jpg\" alt=\"on switch image\" class=\"hasloo-switch-image\" style=\"display:none\" /><img id=\"switch-off\" src=\"" . compat_get_plugin_url( 'hasloo' ) .  "/themes/core/core-images/off.jpg\" alt=\"off switch image\" class=\"hasloo-switch-image\" /></a>";
 		echo '</div>';
	}
}
  
function bnc_options_menu() {
	add_options_page( __( 'hasloo iPhone Theme', 'hasloo' ), 'hasloo', 9, __FILE__, bnc_wp_touch_page );
}

function bnc_hasloo_get_settings() {
	return bnc_wp_touch_get_menu_pages();
}

function bnc_validate_hasloo_settings( &$settings ) {
	global $hasloo_defaults;
	foreach ( $hasloo_defaults as $key => $value ) {
		if ( !isset( $settings[$key] ) ) {
			$settings[$key] = $value;
		}
	}
}

function bnc_hasloo_is_exclusive() {
	$settings = bnc_hasloo_get_settings();
	return $settings['enable-exclusive'];
}

function bnc_can_show_tweets() {
	$settings = bnc_hasloo_get_settings();
	return $settings['enable-show-tweets'];
}

function bnc_wp_touch_get_menu_pages() {
	$v = get_option('bnc_iphone_pages');
	if (!$v) {
		$v = array();
	}
	
	if (!is_array($v)) {
		$v = unserialize($v);
	}
	
	bnc_validate_hasloo_settings( $v );

	return $v;
}

function bnc_get_selected_home_page() {
   $v = bnc_wp_touch_get_menu_pages();
   return $v['home-page'];
}

function hasloo_get_stats() {
	$options = bnc_wp_touch_get_menu_pages();
	if (isset($options['statistics'])) {
		echo stripslashes($options['statistics']);
	}
}
  
function bnc_get_title_image() {
	$ids = bnc_wp_touch_get_menu_pages();
	$title_image = $ids['main_title'];

	if ( file_exists( compat_get_plugin_dir( 'hasloo' ) . '/images/icon-pool/' . $title_image ) ) {
		$image = compat_get_plugin_url( 'hasloo' ) . '/images/icon-pool/' . $title_image;
	} else if ( file_exists( compat_get_upload_dir() . '/hasloo/custom-icons/' . $title_image ) ) {
		$image = compat_get_upload_url() . '/hasloo/custom-icons/' . $title_image;
	}

	return $image;
}

function hasloo_excluded_cats() {
	$settings = bnc_hasloo_get_settings();
	return stripslashes($settings['excluded-cat-ids']);
}

function bnc_excerpt_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-post-excerpts'];
}	

function bnc_is_page_coms_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-page-coms'];
}		

function bnc_is_cats_button_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-cats-button'];
}	

function bnc_is_tags_button_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-tags-button'];
}	

function bnc_is_search_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-search-button'];
}	

function bnc_is_gigpress_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-gigpress-button'];
}	

function bnc_is_flat_icon_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-flat-icon'];
}	

function bnc_is_login_button_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-login-button'];
}		
	
function bnc_is_gravatars_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-gravatars'];
}	

function bnc_show_author() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-main-name'];
}

function bnc_show_tags() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-main-tags'];
}

function bnc_show_categories() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-main-categories'];
}

function bnc_is_home_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-main-home'];
}	

function bnc_is_rss_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-main-rss'];
}	

function bnc_is_email_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-main-email'];
}

function bnc_is_truncated_enabled() {
	$ids = bnc_wp_touch_get_menu_pages();
	return $ids['enable-truncated-titles'];	
}

// Prowl Functions
function bnc_is_prowl_direct_message_enabled() {
	$settings = bnc_hasloo_get_settings();
	return ( isset( $settings['enable-prowl-message-button'] ) && $settings['enable-prowl-message-button'] && $settings['prowl-api'] );
}

function bnc_prowl_did_try_message() {
	global $hasloo_plugin;
	return $hasloo_plugin->prowl_output;
}

function bnc_prowl_message_success() {
	global $hasloo_plugin;
	return $hasloo_plugin->prowl_success;
}
// End prowl functions
  
function bnc_wp_touch_get_pages() {
	global $table_prefix;
	global $wpdb;
	
	$ids = bnc_wp_touch_get_menu_pages();
	$a = array();
	$keys = array();
	foreach ($ids as $k => $v) {
		if ($k == 'main_title' || $k == 'enable-post-excerpts' || $k == 'enable-page-coms' || 
			 $k == 'enable-cats-button'  || $k == 'enable-tags-button'  || $k == 'enable-search-button'  || 
			 $k == 'enable-login-button' || $k == 'enable-gravatars' || 
			 $k == 'enable-main-home' || $k == 'enable-main-rss' || $k == 'enable-main-email' || 
			 $k == 'enable-truncated-titles' || $k == 'enable-main-name' || $k == 'enable-main-tags' || 
			 $k == 'enable-main-categories' || $k == 'enable-prowl-comments-button' || $k == 'enable-prowl-users-button' || 
			 $k == 'enable-prowl-message-button' || $k == 'enable-gigpress-button'  || $k == 'enable-flat-icon') {
			} else {
				if (is_numeric($k)) {
					$keys[] = $k;
				}
			}
	}
	 
	$menu_order = array(); 
	$results = false;

	if ( count( $keys ) > 0 ) {
		$query = "select * from {$table_prefix}posts where ID in (" . implode(',', $keys) . ") and post_status = 'publish' order by post_title asc";
		$results = $wpdb->get_results( $query, ARRAY_A );
	}

	if ( $results ) {
		foreach ( $results as $row ) {
			$row['icon'] = $ids[$row['ID']];
			$a[$row['ID']] = $row;
			if (isset($menu_order[$row['menu_order']])) {
				$menu_order[$row['menu_order']*100 + $inc] = $row;
			} else {
				$menu_order[$row['menu_order']*100] = $row;
			}
			$inc = $inc + 1;
		}
	}

	if (isset($ids['sort-order']) && $ids['sort-order'] == 'page') {
		asort($menu_order);
		return $menu_order;
	} else {
		return $a;
	}
}

function bnc_get_header_title() {
	$v = bnc_wp_touch_get_menu_pages();
	return $v['header-title'];
}

function bnc_get_header_background() {
	$v = bnc_wp_touch_get_menu_pages();
	return $v['header-background-color'];
}
  
function bnc_get_header_border_color() {
	$v = bnc_wp_touch_get_menu_pages();
	return $v['header-border-color'];
}

function bnc_get_header_color() {
	$v = bnc_wp_touch_get_menu_pages();
	return $v['header-text-color'];
}

function bnc_get_link_color() {
	$v = bnc_wp_touch_get_menu_pages();
	return $v['link-color'];
}

function bnc_get_h2_font() {
	$v = bnc_wp_touch_get_menu_pages();
	return $v['h2-font'];
}

function bnc_get_icon_style() {
	$v = bnc_wp_touch_get_menu_pages();
	return $v['icon-style'];
}

require_once( 'include/icons.php' );
  
function bnc_wp_touch_page() {
	if (isset($_POST['submit'])) {
		echo('<div class="wrap"><div id="bnc-global"><div id="haslooupdated" style="display:none"><p class="saved"><span>');
		echo __( "Settings saved", "hasloo");
		echo('</span></p></div>');
		} 
	elseif (isset($_POST['reset'])) {
		echo('<div class="wrap"><div id="bnc-global"><div id="haslooupdated" style="display:none"><p class="reset"><span>');
		echo __( "Defaults restored", "hasloo");
		echo('</span></p></div>');
	} else {
		echo('<div class="wrap"><div id="bnc-global">');
}
?>

<?php $icons = bnc_get_icon_list(); ?>

	<?php require_once( 'include/submit.php' ); ?>
	<form method="post" action="<?php echo admin_url( 'options-general.php?page=hasloo/hasloo.php' ); ?>">
		<?php require_once( 'html/head-area.php' ); ?>
		<?php require_once( 'html/general-settings-area.php' ); ?>
		<?php require_once( 'html/advanced-area.php' ); ?>
		<?php require_once( 'html/push-area.php' ); ?>
		<?php require_once( 'html/style-area.php' ); ?>
		<?php require_once( 'html/icon-area.php' ); ?>
		<?php require_once( 'html/page-area.php' ); ?>
		<?php require_once( 'html/ads-stats-area.php' ); ?>
		<?php require_once( 'html/plugin-compat-area.php' ); ?>		
		<input type="submit" name="submit" value="<?php _e('Save Options', 'hasloo' ); ?>" id="bnc-button" class="button-primary" />
	</form>
	
	<!-- <form method="post" action="<?php echo admin_url( 'options-general.php?page=hasloo/hasloo.php' ); ?>"> -->
	<form method="post" action="">
		<input type="submit" onclick="return confirm('<?php _e('Restore default hasloo settings?', 'hasloo' ); ?>');" name="reset" value="<?php _e('Restore Defaults', 'hasloo' ); ?>" id="bnc-button-reset" class="button-highlighted" />
	</form>
		
		<?php echo('' . hasloo('<div class="bnc-plugin-version"> This is ','</div>') . ''); ?>

	<div class="bnc-clearer"></div>
</div>
<?php 
echo('</div>'); } 
add_action('wp_footer', 'hasloo_switch');
add_action('admin_head', 'hasloo_admin_files');
add_action('admin_menu', 'bnc_options_menu'); 
add_filter( 'plugin_action_links', 'hasloo_settings_link', 9, 2 );
?>