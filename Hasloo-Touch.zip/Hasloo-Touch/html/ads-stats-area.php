<?php global $hasloo_settings; ?>

<div class="metabox-holder">
	<div class="postbox">
		<h3><span class="adsense-options">&nbsp;</span><?php _e( "Adsense, Stats &amp; Custom Code", "hasloo" ); ?></h3>

			<div class="left-content">
				<h4><?php _e( "Adsense", "hasloo" ); ?></h4>
					<p><?php _e( "Enter your Google AdSense ID if you'd like to support mobile advertising in hasloo posts.", "hasloo" ); ?></p>
					<p><?php _e( "Make sure to include the 'pub-' part of your ID string.", "hasloo" ); ?></p>
				<br />
			    <h4><?php _e( "Stats &amp; Custom Code", "hasloo" ); ?></h4>
			 		<p><?php _e( "If you'd like to capture traffic statistics ", "hasloo" ); ?><br /><?php _e( "(Google Analytics, MINT, etc.)", "hasloo" ); ?></p>
			 		<p><?php _e( "Enter the code snippet(s) for your statistics tracking here.", "hasloo" ); ?></p>
			 		<p><?php _e( "You can also enter custom CSS &amp; other code here.", "hasloo" ); ?> <a href="#css-info" class="fancylink">?</a></p>
			 		<div id="css-info" style="display:none">
					<h2><?php _e( "More Info", "hasloo" ); ?></h2>
					<p><?php _e( "You can enter a custom css file link easily. Simply add the full link to the css file like this:", "hasloo" ); ?></p>
					<p><?php _e( "<code>&lt;link rel=&quot;stylesheet&quot; src=&quot;http://path-to-my-css-file&quot; type=&quot;text/css&quot; media=&quot;screen&quot; /&gt;</code>", "hasloo" ); ?></p>
				</div>

			</div><!-- left content -->

			<div class="right-content">
				<ul class="hasloo-make-li-italic">
					<li><input name="adsense-id" type="text" value="<?php echo $hasloo_settings['adsense-id']; ?>" /><?php _e( "Google AdSense ID", "hasloo" ); ?></li>
					<li><input name="adsense-channel" type="text" value="<?php echo $hasloo_settings['adsense-channel']; ?>" /><?php _e( "Google AdSense Channel", "hasloo" ); ?></li>
				</ul>
			
				<textarea id="hasloo-stats" name="statistics"><?php echo stripslashes($hasloo_settings['statistics']); ?></textarea>

						</div><!-- right content -->
		<div class="bnc-clearer"></div>
	</div><!-- postbox -->
</div><!-- metabox -->