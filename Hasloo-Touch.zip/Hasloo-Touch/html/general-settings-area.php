<?php global $hasloo_settings; ?>

<div class="metabox-holder">
	<div class="postbox">
		<h3><span class="global-settings">&nbsp;</span><?php _e( "General Settings", "hasloo" ); ?></h3>

			<div class="left-content">
				<h4><?php _e( "Home Page Re-Direction", "hasloo" ); ?></h4>
				<p><?php echo sprintf( __( "hasloo by default follows your %sWordPress &raquo; Reading Options%s. You can also set a different one for hasloo.", "hasloo"), '<a href="options-reading.php">', '</a>' ); ?></p>

				<h4><?php _e( "Site Title", "hasloo" ); ?></h4>
				<p><?php _e( "You can shorten your site title here so it won't be truncated by hasloo.", "hasloo" ); ?></p>


				<h4><?php _e( "Excluded Categories", "hasloo" ); ?></h4>
				<p><?php _e( "Choose categories you want excluded from the main post listings in hasloo.", "hasloo" ); ?></p>

				<h4><?php _e( "Font Options", "hasloo" ); ?></h4>
				<p><?php _e( "Set the alignment for text.", "hasloo" ); ?></p>

				
				<h4><?php _e( "Post Listings Options", "hasloo" ); ?></h4>
				<p><?php _e( "Choose between Calendar Icons, Post Thumbnails (WP 2.9) or nothing for your post listings.", "hasloo" ); ?></p>
				<p><?php _e( "Select which post-meta items are shown under titles on the main, search, &amp; archives pages.", "hasloo" ); ?></p>
				<p><?php _e( "Also, choose if excerpts are shown/hidden (default is hidden).", "hasloo" ); ?></p>
			</div>

			<div class="right-content">
				<p><label for="home-page"><strong><?php _e( "hasloo Home Page", "hasloo" ); ?></strong></label></p>
				<?php $pages = bnc_get_pages_for_icons(); ?>
				<?php if ( count( $pages ) ) { ?>
					<?php wp_dropdown_pages( 'show_option_none=WordPress Settings&name=home-page&selected=' . bnc_get_selected_home_page()); ?>
				<?php } else {?>
					<strong class="no-pages"><?php _e( "You have no pages yet. Create some first!", "hasloo" ); ?></strong>
				<?php } ?>

				<br /><br /><br />

				<ul class="hasloo-make-li-italic">
					<li><input type="text" class="no-right-margin" name="header-title" value="<?php $str = $hasloo_settings['header-title']; echo stripslashes($str); ?>" /><?php _e( "Site title text", "hasloo" ); ?></li>
				</ul>

				<br />

				<ul class="hasloo-make-li-italic">			
				<li><input name="excluded-cat-ids" class="no-right-margin" type="text" value="<?php $str = $hasloo_settings['excluded-cat-ids']; echo stripslashes($str); ?>" /><?php _e( "Comma list of Category IDs, eg: 1,2,3", "hasloo" ); ?></li>
				</ul>

				<br />

				<ul class="hasloo-make-li-italic">

					<li><select name="style-text-justify">
							<option <?php if ($hasloo_settings['style-text-justify'] == "left-justified") echo " selected"; ?> value="left-justified"><?php _e( "Left", "hasloo" ); ?></option>
							<option <?php if ($hasloo_settings['style-text-justify'] == "full-justified") echo " selected"; ?> value="full-justified"><?php _e( "Full", "hasloo" ); ?></option>
						</select>
						<?php _e( "Font justification", "hasloo" ); ?>
					</li>
				</ul>	
				
				<br />
				
				<ul>
				<li><ul class="hasloo-make-li-italic">
		
							<li><select name="post-cal-thumb">
									<option <?php if ($hasloo_settings['post-cal-thumb'] == "calendar-icons") echo " selected"; ?> value="calendar-icons"><?php _e( "Calendar Icons", "hasloo" ); ?></option>
									<option <?php $version = bnc_get_wp_version(); if ($version <= 2.89) : ?>disabled="true"<?php endif; ?> <?php if ($hasloo_settings['post-cal-thumb'] == "post-thumbnails") echo " selected"; ?> value="post-thumbnails"><?php _e( "Post Thumbnails", "hasloo" ); ?></option>
									<option <?php $version = bnc_get_wp_version(); if ($version <= 2.89) : ?>disabled="true"<?php endif; ?> <?php if ($hasloo_settings['post-cal-thumb'] == "post-thumbnails-random") echo " selected"; ?> value="post-thumbnails-random"><?php _e( "Post Thumbnails (Random)", "hasloo" ); ?></option>
									<option <?php if ($hasloo_settings['post-cal-thumb'] == "nothing-shown") echo " selected"; ?> value="nothing-shown"><?php _e( "No Icon or Thumbnail", "hasloo" ); ?></option>
								</select>
								<?php _e( "Post Listings Display", "hasloo" ); ?> <small>(<?php _e( "Thumbnails Requires WordPress 2.9+", "hasloo" ); ?>)</small> <a href="#thumbs-info" class="fancylink">?</a>
				<div id="thumbs-info" style="display:none">
					<h2><?php _e( "More Info", "hasloo" ); ?></h2>
					<p><?php _e( "This will change the display of blog and post listings between Calendar Icons view and Post Thumbnails view.", "hasloo" ); ?></p>
					<p><?php _e( "The <em>Post Thumbnails w/ Random</em> option will fill missing post thumbnails with random abstract images. (WP 2.9+)", "hasloo" ); ?></p>
				</div>

							</li>
						</ul>	
					</li>
					<li>
						<input type="checkbox" class="checkbox" name="enable-truncated-titles" <?php if (isset($hasloo_settings['enable-truncated-titles']) && $hasloo_settings['enable-truncated-titles'] == 1) echo('checked'); ?> />
						<label for="enable-truncated-titles"><?php _e( "Enable Truncated Titles", "hasloo" ); ?> <small>(<?php _e( "Will use ellipses when titles are too long instead of wrapping them", "hasloo" ); ?>)</small></label>
					</li>					
					<li>
						<input type="checkbox" class="checkbox" name="enable-main-name" <?php if (isset($hasloo_settings['enable-main-name']) && $hasloo_settings['enable-main-name'] == 1) echo('checked'); ?> />
						<label for="enable-authorname"> <?php _e( "Show Author's Name", "hasloo" ); ?></label>
					</li>			
					<li>
						<input type="checkbox" class="checkbox" name="enable-main-categories" <?php if (isset($hasloo_settings['enable-main-categories']) && $hasloo_settings['enable-main-categories'] == 1) echo('checked'); ?> />
						<label for="enable-categories"> <?php _e( "Show Categories", "hasloo" ); ?></label>
					</li>			
					<li>
						<input type="checkbox" class="checkbox" name="enable-main-tags" <?php if (isset($hasloo_settings['enable-main-tags']) && $hasloo_settings['enable-main-tags'] == 1) echo('checked'); ?> />
						<label for="enable-tags"> <?php _e( "Show Tags", "hasloo" ); ?></label>
					</li>			
					<li>
						<input type="checkbox" class="checkbox" name="enable-post-excerpts" <?php if (isset($hasloo_settings['enable-post-excerpts']) && $hasloo_settings['enable-post-excerpts'] == 1) echo('checked'); ?> />
						<label for="enable-excerpts"><?php _e( "Hide Excerpts", "hasloo" ); ?></label>
					</li>
				</ul>	
			</div>
			
	<div class="bnc-clearer"></div>
	</div><!-- postbox -->
</div><!-- metabox -->