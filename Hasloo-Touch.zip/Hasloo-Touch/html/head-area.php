<?php global $hasloo_settings; ?>
<?php global $bnc_hasloo_version; ?>

<div class="metabox-holder" id="hasloo-head">
	<div class="postbox">
		<div id="hasloo-head-colour">
			<div id="hasloo-head-title">
				<?php hasloo(); ?>
				<img class="ajax-load" src="<?php echo compat_get_plugin_url('hasloo'); ?>/images/admin-ajax-loader.gif" alt="ajax"/>
			</div>
				<div id="hasloo-head-links">
					<ul>
						<!-- <li><?php echo sprintf(__( "%sSupport Forums%s", "hasloo" ), '<a href="http://support.bravenewcode.com/forum/hasloo" target="_blank">','</a>'); ?> | </li> -->
						<li><?php echo sprintf(__( "%shasloo Homepage%s", "hasloo" ), '<a href="http://www.bravenewcode.com/hasloo" target="_blank">','</a>'); ?> | </li>
						<!-- <li><?php echo sprintf(__( "%sSupport Forums%s", "hasloo" ), '<a href="http://www.bravenewcode.com/support/" target="_blank">','</a>'); ?> | </li> -->
						<li><?php echo sprintf(__( "%sBNC on Twitter%s", "wordtwit" ), '<a href="http://www.twitter.com/bravenewcode" target="_blank">','</a>'); ?> | </li>
						<li><?php echo sprintf(__( "%sDonate%s", "hasloo" ), '<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&amp;business=paypal%40bravenewcode%2ecom&amp;item_name=hasloo%20Beer%20Fund&amp;no_shipping=1&amp;tax=0&amp;currency_code=CAD&amp;lc=CA&amp;bn=PP%2dDonationsBF&amp;charset=UTF%2d8" target="_blank">','</a>'); ?></li>
					</ul>
				</div>
	<div class="bnc-clearer"></div>
			</div>	
	
		<div id="hasloo-news-support">

			<div id="hasloo-news-wrap">
			<h3><span class="rss-head">&nbsp;</span><?php _e( "hasloo Wire", "hasloo" ); ?></h3>
				<div id="hasloo-news-content">
					
				</div>
			</div>

			<div id="hasloo-support-wrap">			
			<h3>&nbsp;</h3>
				<div id="hasloo-support-content">
				<p id="find-out-more"><a href="http://www.hasloo.com" target="_blank"><?php _e( "Find Out More &rsaquo;", "hasloo" ); ?></a></p>
				</div>
			</div>
			
		</div><!-- hasloo-news-support -->

	<div class="bnc-clearer"></div>
	</div><!-- postbox -->
</div><!-- hasloo-head -->
