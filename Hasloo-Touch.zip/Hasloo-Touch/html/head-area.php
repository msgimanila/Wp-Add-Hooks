<?php global $hasloo_settings; ?>
<?php global $bnc_hasloo_version; ?>

<div class="metabox-holder" id="hasloo-head">
	<div class="postbox">
		<div id="hasloo-head-colour">
			<div id="hasloo-head-title">
				<?php hasloo(); ?>
				<img class="ajax-load" src="<?php echo compat_get_plugin_url('hasloo'); ?>/images/admin-ajax-loader.gif" alt="ajax"/>
			</div>
				<div id="hasloo-head-links">
					<ul>
						 
					</ul>
				</div>
	<div class="bnc-clearer"></div>
			</div>	
	
		<div id="hasloo-news-support">

			<div id="hasloo-news-wrap">
			<h3><span class="rss-head">&nbsp;</span><?php _e( "hasloo Wire", "hasloo" ); ?></h3>
				<div id="hasloo-news-content">
					
				</div>
			</div>

			<div id="hasloo-support-wrap">			
			<h3>&nbsp;</h3>
				<div id="hasloo-support-content">
				<p id="find-out-more"><a href="http://www.hasloo.com" target="_blank"><?php _e( "Find Out More &rsaquo;", "hasloo" ); ?></a></p>
				</div>
			</div>
			
		</div><!-- hasloo-news-support -->

	<div class="bnc-clearer"></div>
	</div><!-- postbox -->
</div><!-- hasloo-head -->
