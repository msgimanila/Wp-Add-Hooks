<?php global $hasloo_settings; ?>

<div class="metabox-holder">
	<div class="postbox">
		<h3><span class="page-options">&nbsp;</span><?php _e( "Logo Icon // Menu Items &amp; Pages Icons", "hasloo" ); ?></h3>

			<div class="left-content">
				<h4><?php _e( "Logo / Home Screen Icon <br />&amp; Default Menu Items", "hasloo" ); ?></h4>
				<p><?php echo sprintf( __( "If you do not want your logo to have the glossy effect added to it, make sure you select %sEnable Flat Bookmark Icon%s", "hasloo"), "<strong>", "</strong>" ); ?></p>
				<p><?php _e( "Choose the logo displayed in the header (also your bookmark icon), and the pages you want included in the hasloo drop-down menu.", "hasloo" ); ?> 						
				<strong><?php _e( "Remember, only those checked will be shown.", "hasloo" ); ?></strong></p>
				<p><?php _e( "Enable/Disable default items in the hasloo site menu.", "hasloo"); ?></p>
<br /><br />
				<h4><?php _e( "Pages + Icons", "hasloo" ); ?></h4>
				<p><?php _e( "Next, select the icons from the lists that you want to pair with each page menu item.", "hasloo" ); ?></p>
				<p><?php _e( "You can also decide if pages are listed by the page order (ID) in WordPress, or by name (default).", "hasloo" ); ?></p>
			</div><!-- left-content -->
		
	<div class="right-content hasloo-pages">
		<ul>
			<li><select name="enable_main_title">
					<?php bnc_get_icon_drop_down_list( $hasloo_settings['main_title']); ?>
				</select>
				<?php _e( "Logo &amp; Home Screen Bookmark Icon", "hasloo" ); ?>
				<br />
			</li>
		</ul>
		<ul>
			<li><input type="checkbox" class="checkbox" name="enable-flat-icon" <?php if (isset($hasloo_settings['enable-flat-icon']) && $hasloo_settings['enable-flat-icon'] == 1) echo('checked'); ?> /><label for="enable-flat-icon"><?php _e( "Enable Flat Bookmark Icon", "hasloo" ); ?> <a href="#logo-info" class="fancylink">?</a></label>
			<div id="logo-info" style="display:none">
				<h2><?php _e( "More Info", "hasloo" ); ?></h2>
				<p><?php _e( "The default applies for iPhone/iPod touch applies a glossy effect to the home-screen bookmark/logo icon you select.", "hasloo" ); ?></p>
				<p><?php _e( "When checked your icon will not have the glossy effect automatically applied to it.", "hasloo" ); ?></p>
			</div>
			</li>
			<li><input type="checkbox" class="checkbox" name="enable-main-home" <?php if (isset($hasloo_settings['enable-main-home']) && $hasloo_settings['enable-main-home'] == 1) echo('checked'); ?> /><label for="enable-main-home"><?php _e( "Enable Home Menu Item", "hasloo" ); ?></label></li>
			<li><input type="checkbox" class="checkbox" name="enable-main-rss" <?php if (isset($hasloo_settings['enable-main-rss']) && $hasloo_settings['enable-main-rss'] == 1) echo('checked'); ?> /><label for="enable-main-rss"><?php _e( "Enable RSS Menu Item", "hasloo" ); ?></label></li>
			<li><input type="checkbox" class="checkbox" name="enable-main-email" <?php if (isset($hasloo_settings['enable-main-email']) && $hasloo_settings['enable-main-email'] == 1) echo('checked'); ?> /><label for="enable-main-email"><?php _e( "Enable Email Menu Item", "hasloo" ); ?> <small>(<?php _e( "Uses default WordPress admin e-mail", "hasloo" ); ?>)</small></label><br /><br /><br /></li>
		
		<?php if ( count( $pages ) ) { ?>
			<li><br /><br />
			<select name="sort-order">
					<option value="name"<?php if ( $hasloo_settings['sort-order'] == 'name') echo " selected"; ?>><?php _e( "By Name", "hasloo" ); ?></option>
					<option value="page"<?php if ( $hasloo_settings['sort-order'] == 'page') echo " selected"; ?>><?php _e( "By Page ID", "hasloo" ); ?></option>
				</select>
				<?php _e( "Menu List Sort Order", "hasloo" ); ?>
			</li>
			<?php } ?>
			<?php $pages = bnc_get_pages_for_icons(); ?>
			<?php if ( count( $pages ) ) { ?>
				<?php foreach ( $pages as $page ) { ?>
				<li><span>
						<input class="checkbox" type="checkbox" name="enable_<?php echo $page->ID; ?>"<?php if ( isset( $hasloo_settings[$page->ID] ) ) echo " checked"; ?> />
						<label class="hasloo-page-label" for="enable_<?php echo $page->ID; ?>"><?php echo $page->post_title; ?> <?php _e( "Page", "hasloo" ); ?></label>
					</span>
					<select class="page-select" name="icon_<?php echo $page->ID; ?>">
						<?php bnc_get_icon_drop_down_list( $hasloo_settings[ $page->ID ]); ?>
					</select>
					
				</li>
				<?php } ?>
			<?php } else { ?>
				<strong ><?php _e( "You have no pages yet. Create some first!", "hasloo" ); ?></strong>
			<?php } ?>
		</ul>
	</div><!-- right-content -->		
	<div class="bnc-clearer"></div>
	</div><!-- postbox -->
</div><!-- metabox -->