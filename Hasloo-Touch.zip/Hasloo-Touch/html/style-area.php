<?php global $hasloo_settings; ?>

<div class="metabox-holder">
	<div class="postbox">
		<h3><span class="style-options">&nbsp;</span><?php _e( "Style &amp; Color Options", "hasloo" ); ?></h3>

			<div class="left-content skins-left-content">
				<p><?php _e( "Here you can customize some of the more visible features of hasloo.", "hasloo" ); ?></p>
			</div>
		
			<div class="right-content skins-fixed">


 <!-- Default skin -->
 
		<div class="skins-desc" id="default-skin">
			<p><?php _e( "The default hasloo theme emulates a native iPhone application.", "hasloo" ); ?></p>
			<ul class="hasloo-make-li-italic">
					<li><select name="style-background">
							<option <?php if ($hasloo_settings['style-background'] == "classic-hasloo-bg") echo " selected"; ?> value="classic-hasloo-bg">
								<?php _e( "Classic", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['style-background'] == "horizontal-hasloo-bg") echo " selected"; ?> value="horizontal-hasloo-bg">
								<?php _e( "Horizontal Grey", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['style-background'] == "diagonal-hasloo-bg") echo " selected"; ?> value="diagonal-hasloo-bg">
								<?php _e( "Diagonal Grey", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['style-background'] == "skated-hasloo-bg") echo " selected"; ?> value="skated-hasloo-bg">
								<?php _e( "Skated Concrete", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['style-background'] == "argyle-hasloo-bg") echo " selected"; ?> value="argyle-hasloo-bg">
								<?php _e( "Argyle Tie", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['style-background'] == "grid-hasloo-bg") echo " selected"; ?> value="grid-hasloo-bg">
								<?php _e( "Thatches", "hasloo" ); ?>
							</option>
						</select>
						<?php _e( "Background", "hasloo" ); ?>
					</li> 
					<li><select name="h2-font">
							<option <?php if ($hasloo_settings['h2-font'] == "Helvetica Neue") echo " selected"; ?> value="Helvetica Neue">
								<?php _e( "Helvetica Neue", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['h2-font'] == "Helvetica") echo " selected"; ?> value="Helvetica">
								<?php _e( "Helvetica", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['h2-font'] == "thonburi-font") echo " selected"; ?> value="thonburi-font">
								<?php _e( "Thonburi", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['h2-font'] == "Georgia") echo " selected"; ?> value="Georgia">
								<?php _e( "Georgia", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['h2-font'] == "Geeza Pro") echo " selected"; ?> value="Geeza Pro">
								<?php _e( "Geeza Pro", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['h2-font'] == "Verdana") echo " selected"; ?> value="Verdana">
								<?php _e( "Verdana", "hasloo" ); ?>
							</option>
							<option <?php if ($hasloo_settings['h2-font'] == "Arial Rounded MT Bold") echo " selected"; ?> value="Arial Rounded MT Bold">
								<?php _e( "Arial Rounded MT Bold", "hasloo" ); ?>
							</option>
							</select>
						<?php _e( "Post Title H2 Font", "hasloo" ); ?>
					</li> 
					<li>#<input type="text" id="header-text-color" name="header-text-color" value="<?php echo $hasloo_settings['header-text-color']; ?>" /><?php _e( "Title text color", "hasloo" ); ?></li>
					<li>#<input type="text" id="header-background-color" name="header-background-color" value="<?php echo $hasloo_settings['header-background-color']; ?>" /><?php _e( "Header background color", "hasloo" ); ?></li>
					<li>#<input type="text" id="header-border-color" name="header-border-color" value="<?php echo $hasloo_settings['header-border-color']; ?>" /><?php _e( "Sub-header background color", "hasloo" ); ?></li>
					<li>#<input type="text" id="link-color" name="link-color" value="<?php echo $hasloo_settings['link-color']; ?>" /><?php _e( "Site-wide links color", "hasloo" ); ?></li>
			</ul> 
		</div>
		
		</div><!-- right content -->
	<div class="bnc-clearer"></div>
	</div><!-- postbox -->
</div><!-- metabox -->