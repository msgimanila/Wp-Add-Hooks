/*
 * hasloo 1.9.x -The hasloo Core JS File
 * This file holds all the default jQuery & Ajax functions for the theme
 * Copyright (c) 2008 - 2010 Duane Storey & Dale Mugford (BraveNewCode Inc.)
 * Licensed under GPL.
 *
 * Last Updated: May 4th, 2010
 */

/////// -- Let's setup a unique namspace in jQuery -- ///////
$hasloo = jQuery.noConflict();

/////// -- Get out of frames! -- ///////
if (top.location!= self.location) {top.location = self.location.href}

/////// --New function fadeToggle() -- ///////
$hasloo.fn.fadeToggle = function(speed, easing, callback) { 
	return this.animate({opacity: 'toggle'}, speed, easing, callback); 
};

/////// -- Switch Magic -- ///////
function hasloo_switch_confirmation() {
if (document.cookie && document.cookie.indexOf("hasloo_switch_cookie") > -1) {
// just switch
	$hasloo("a#switch-link").toggleClass("offimg");
	setTimeout('switch_delayer()', 1250); 
} else {
// ask first
	var answer = confirm("Switch to regular view? \n \n You can switch back to mobile view again in the footer.");
	if (answer){
	$hasloo("a#switch-link").toggleClass("offimg");
	setTimeout('switch_delayer()', 1350); 
		}
	}
}

/////// -- Prowl Results -- ///////
setTimeout(function() { $hasloo('#prowl-success').fadeOut(400); }, 5250);
setTimeout(function() { $hasloo('#prowl-fail').fadeOut(400); }, 5250);

/////// -- Menu Toggles, Effects -- ///////
function bnc_jquery_menu_drop() {
	$hasloo('#hasloo-menu').fadeToggle(400);
	$hasloo("#headerbar-menu a").toggleClass("open");
}

function bnc_jquery_login_toggle() { $hasloo('#hasloo-login').fadeToggle(400);}
function bnc_jquery_search_toggle() { $hasloo('#hasloo-search').fadeToggle(400);}
function bnc_jquery_gigpress_toggle() { $hasloo('#hasloo-gigpress').fadeToggle(400);}
function bnc_jquery_prowl_open() { $hasloo('#prowl-message').fadeToggle(400);}
function bnc_jquery_wordtwit_open() { $hasloo('#hasloo-wordtwit').fadeToggle(400);}


/////// --Single Post Page -- ///////
function hasloo_toggle_twitter() {
	$hasloo('#twitter-box').fadeToggle(400);
}

function hasloo_toggle_bookmarks() {
	$hasloo('#bookmark-box').fadeToggle(400);
}

/////// --jQuery Tabs-- ///////
$hasloo(function () {
    var tabContainers = $hasloo('#menu-head > ul');   
    $hasloo('#tabnav a').click(function () {
        tabContainers.hide().filter(this.hash).show();
    $hasloo('#tabnav a').removeClass('selected');
    $hasloo(this).addClass('selected');
        return false;
    }).filter(':first').click();
});

/////// -- Ajax comments -- ///////
function bnc_showhide_coms_toggle() {
	$hasloo('#commentlist').fadeToggle(400);
	$hasloo("img#com-arrow").toggleClass("com-arrow-down");
	$hasloo("h3#com-head").toggleClass("comhead-open");
}
	
function dohaslooReady() {

/////// -- Tweak jQuery Timer -- ///////
	$hasloo.timerId = setInterval(function(){
		var timers = $hasloo.timers;
		for (var i = 0; i < timers.length; i++) {
			if (!timers[i]()) {
				timers.splice(i--, 1);
			}
		}
		if (!timers.length) {
			clearInterval($hasloo.timerId);
			$hasloo.timerId = null;
		}
	}, 83);

}

$hasloo( document ).ready( function() { dohaslooReady(); } );

// End hasloo jS