<div id="footer">

	<center>
		<div id="hasloo-switch-link">
			<?php hasloo_core_footer_switch_link(); ?>
		</div>
	</center>
	
	<p><?php _e( "All content Copyright &copy;", "hasloo" ); ?> <?php $str = bnc_get_header_title(); echo stripslashes($str); ?></p>
	<p><?php _e( 'Powered by', 'hasloo' ); ?> <a href="http://www.wordpress.org/"><?php _e( 'WordPress', 'hasloo' ); ?></a> <?php _e( '+', 'hasloo' ); ?> <a href="http://www.hasloo.com">Hasloo.com</a></p>
	<?php if ( !bnc_hasloo_is_exclusive() ) { wp_footer(); } ?>
</div>

<?php hasloo_get_stats(); 
// hasloo theme designed and developed by Dale Mugford and Duane Storey for BraveNewCode.com
// If you modify it for yourself, please keep the link credit *visible* in the footer (and keep the WordPress credit, too!) that's all we ask folks.
?>
</body>
</html>