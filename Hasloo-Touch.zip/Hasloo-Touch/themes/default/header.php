<?php 
include( dirname(__FILE__) . '/../core/core-header.php' ); 
// End hasloo Core Header
?>
<body class="<?php hasloo_core_body_background(); ?>">
<!-- New noscript check, we need js on now folks -->
<noscript>
<div id="noscript-wrap">
	<div id="noscript">
		<h2><?php _e("Notice", "hasloo"); ?></h2>
		<p><?php _e("JavaScript for Mobile Safari is currently turned off.", "hasloo"); ?></p>
		<p><?php _e("Turn it on in ", "hasloo"); ?><em><?php _e("Settings &rsaquo; Safari", "hasloo"); ?></em><br /><?php _e(" to view this website.", "hasloo"); ?></p>
	</div>
</div>
</noscript>
<!-- Prowl: if DM is sent, let's tell the user what happened -->
<?php if (bnc_prowl_did_try_message()) { if (bnc_prowl_message_success()) { ?>
<div id="prowl-success"><p><?php _e("Your Push Notification was sent.", "hasloo"); ?></p></div>
	<?php } else { ?>
<div id="prowl-fail"><p><?php _e("Your Push Notification cannot be delivered at this time.", "hasloo"); ?></p></div>
<?php } } ?>

<!--#start The Login Overlay -->
	<div id="hasloo-login">
		<div id="hasloo-login-inner">
			<form name="loginform" id="loginform" action="<?php bloginfo('wpurl'); ?>/wp-login.php" method="post">
				<label><input type="text" name="log" id="log" onFocus="if (this.value == 'username') {this.value = ''}" value="username" /></label>
				<label><input type="password" name="pwd"  onfocus="if (this.value == 'password') {this.value = ''}" id="pwd" value="password" /></label>
				<input type="hidden" name="rememberme" value="forever" />
				<input type="hidden" id="logsub" name="submit" value="<?php _e('Login'); ?>" tabindex="9" />
				<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>"/>
			<a href="javascript:return false;" onClick="bnc_jquery_login_toggle();"><img class="head-close" src="<?php echo compat_get_plugin_url( 'hasloo' ); ?>/themes/core/core-images/head-close.png" alt="close" /></a>
			</form>
		</div>
	</div>

 <!-- #start The Search Overlay -->
	<div id="hasloo-search"> 
 		<div id="hasloo-search-inner">
			<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
				<input type="text" value="Search..." onFocus="if (this.value == 'Search...') {this.value = ''}" name="s" id="s" /> 
				<input name="submit" type="hidden" tabindex="1" value="Search"  />
			<a href="javascript:return false;" onClick="bnc_jquery_search_toggle(); $hasloo('input#s').blur();"><img class="head-close" src="<?php echo compat_get_plugin_url( 'hasloo' ); ?>/themes/core/core-images/head-close.png" alt="close" /></a>
			</form>
		</div>
	</div>

	<div id="hasloo-menu" class="dropper"> 		
        <div id="hasloo-menu-inner">
	        <div id="menu-head">
	        	<div id="tabnav">
					<a href="#head-pages"><?php _e("Menu", "hasloo"); ?></a>
		        	<?php if (bnc_is_tags_button_enabled()) { hasloo_tags_link(); } ?>
	    	    	<?php if (bnc_is_cats_button_enabled()) { hasloo_cats_link(); } ?>
	    	    	<?php if (bnc_is_login_button_enabled()) { ?>
						<?php if (!is_user_logged_in()) { ?>
						    <a href="javascript:return false;" onClick="bnc_jquery_login_toggle();"><?php _e( 'Login', 'hasloo' ); ?></a>
						<?php } else { ?>
							 <a href="#head-account"><?php _e( 'My Account', 'hasloo' ); ?></a>
						<?php } ?>
					<?php } ?>
	        	</div>
	
				<ul id="head-pages">
					<?php hasloo_core_header_home(); ?>            
					<?php hasloo_core_header_pages(); ?>
					<?php hasloo_core_header_rss(); ?>
					<?php hasloo_core_header_email(); ?>           
				</ul>
	
				<ul id="head-cats">
	  	 			<?php bnc_get_ordered_cat_list(); ?>
				</ul>
	
				<ul id="head-tags">
					<li><?php wp_tag_cloud('smallest=13&largest=13&unit=px&number=20&order=asc&format=list'); ?></li>
				</ul>

		<ul id="head-account">
				<?php if (!is_user_logged_in()) { ?>
				    <li class="text">
				    	<?php _e( "Enter your username and password<br />in the boxes above.", "hasloo" ); ?>
						<?php if (!get_option('comment_registration')) : ?>
							<?php echo sprintf(__( "<br /><br />Not registered yet?<br />You can %ssign-up here%s.", "hasloo" ), '<a href="' . get_bloginfo('wpurl') . '/wp-register.php" target="_blank">','</a>'); ?>
						<?php endif; ?>
				    </li>
				<?php } else { ?>
					<?php if (current_user_can('edit_posts')) : ?>
					<li><a href="<?php bloginfo('wpurl'); ?>/wp-admin/"><?php _e("Admin", "hasloo"); ?></a></li>
					<?php endif; ?>
					<?php if (get_option('comment_registration')) { ?>
					<li><a href="<?php bloginfo('wpurl'); ?>/wp-register.php"><?php _e( "Register for this site", "hasloo" ); ?></a></li>
					<?php } ?>
					<?php if (is_user_logged_in()) { ?>
					<li><a href="<?php bloginfo('wpurl'); ?>/wp-admin/profile.php"><?php _e( "Account Profile", "hasloo" ); ?></a></li>
					<li><a href="<?php $version = (float)get_bloginfo('version'); if ($version >= 2.7) { ?><?php echo wp_logout_url($_SERVER['REQUEST_URI']); } else { bloginfo('wpurl'); ?>/wp-login.php?action=logout&redirect_to=<?php echo $_SERVER['REQUEST_URI']; ?><?php } ?>"><?php _e( "Logout", "hasloo" ); ?></a></li>
					<?php } ?>
				<?php } ?>
			</ul>
			</div>
		</div>
    </div>

	
<div id="headerbar">
	<div id="headerbar-title">
		<!-- This fetches the admin selection logo icon for the header, which is also the bookmark icon -->
		<img id="logo-icon" src="<?php echo bnc_get_title_image(); ?>" alt="<?php $str = bnc_get_header_title(); echo stripslashes($str); ?>" />
		<a href="<?php bloginfo('home'); ?>"><?php hasloo_core_body_sitetitle(); ?></a>
	</div>
	<div id="headerbar-menu">
		    <a href="javascript:return false;" onClick="bnc_jquery_menu_drop();"></a>
	</div>
</div>

<div id="drop-fade">
	<?php if (bnc_is_search_enabled()) { ?>			    
    	<a id="searchopen" class="top" href="javascript:return false;" onClick="bnc_jquery_search_toggle(); $hasloo('input#s').focus();"><?php _e( 'Search', 'hasloo' ); ?></a>
	<?php } ?>

	<?php if (bnc_is_prowl_direct_message_enabled()) { ?>			    
    	<a id="prowlopen" class="top" href="javascript:return false;" onClick="bnc_jquery_prowl_open();"><?php _e( 'Message', 'hasloo' ); ?></a>
	<?php } ?>

	<?php if ( function_exists( 'wordtwit_get_recent_tweets' ) && wordtwit_is_valid() && bnc_can_show_tweets() ) { ?>		    
    	<a id="wordtwitopen" class="top" href="javascript:return false;" onClick="bnc_jquery_wordtwit_open();"><?php _e( 'Twitter', 'hasloo' ); ?></a>
	<?php } ?>

	<?php if ( function_exists( 'gigpress_shows' ) && bnc_is_gigpress_enabled()) { ?>			    
    	<a id="gigpressopen" class="top" href="javascript:return false;" onClick="bnc_jquery_gigpress_toggle();"><?php _e( 'Tour Dates', 'hasloo' ); ?></a>
	<?php } ?>

 <!-- #start the Prowl Message Area -->
 <div id="prowl-message" style="display:none">
 	 <div id="push-style-bar"></div><!-- filler to get the styling just right -->
	 <img src="<?php echo compat_get_plugin_url( 'hasloo' ); ?>/themes/core/core-images/push-icon.png" alt="push icon" />
	 <h4><?php _e( 'Send a Message', 'hasloo' ); ?></h4>
	 <p><?php _e( 'This message will be pushed to the admin\'s iPhone instantly.', 'hasloo' ); ?></p>
	 
	 <form id="prowl-direct-message" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
	 	<p>
	 		<input name="prowl-msg-name"  id="prowl-msg-name" type="text" />
	 		<label for="prowl-msg-name"><?php _e( 'Name', 'hasloo' ); ?></label>
	 	</p>

		<p>
			<input name="prowl-msg-email" id="prowl-msg-email" type="text" />
			<label for="prowl-msg-email"><?php _e( 'E-Mail', 'hasloo' ); ?></label>
		</p>

		<textarea name="prowl-msg-message"></textarea>
		<input type="hidden" name="hasloo-prowl-message" value="1" /> 
		<input type="hidden" name="_nonce" value="<?php echo wp_create_nonce( 'hasloo-prowl' ); ?>" />			
		<input type="submit" name="prowl-submit" value="<?php _e('Send Now', 'hasloo' ); ?>" id="prowl-submit" />
	 </form>
	<div class="clearer"></div>
 </div>

<?php if ( function_exists( 'wordtwit_get_recent_tweets' ) && wordtwit_is_valid() && bnc_can_show_tweets() ) { ?>
 <!-- #start the WordTwit Twitter Integration -->
 	<?php $tweets = wordtwit_get_recent_tweets(); ?>

	<div id="hasloo-wordtwit" class="dropper" style="display:none">
 	 <div id="twitter-style-bar"></div><!-- filler to get the styling just right -->
			<a  id="follow-arrow" href="http://twitter.com/<?php echo wordtwit_get_username(); ?>" target="_blank"><img src="<?php echo compat_get_plugin_url( 'hasloo' ); ?>/themes/core/core-images/twitter-arrow.jpg" alt="follow me" /></a>
		<div id="wordtwit-avatar">
			<img src="<?php echo wordtwit_get_profile_url(); ?>" alt="Twitter Avatar" />
				<p class="twitter_username"><?php echo wordtwit_get_username(); ?></p>
				<p><a href="http://twitter.com/<?php echo wordtwit_get_username(); ?>" target="_blank">Follow me on Twitter</a></p>
		</div>

		<?php $now = time(); ?>
		<ul id="tweets">
			<?php if ( $tweets ) { ?>
				<?php foreach( $tweets as $tweet ) { ?>
				<li>
					<?php echo strip_tags( $tweet['content'], ''); ?>
					<p class="time"><?php echo wordtwit_friendly_date( $tweet['published'] ); ?></p>
				</li>
		  	 	<?php } ?>
		  	 <?php } else { ?>
		  	 	<li><?php _e( "No recent Tweets.", "hasloo" ); ?><br /><br /></li>

		  	 <?php } ?>
		</ul>
</div>
<?php } ?>

<?php if (function_exists ('gigpress_shows')) { ?>
 <!-- #start the GigPress Area -->
	 <div id="hasloo-gigpress" class="dropper" style="display:none">
	 	 <div id="gigpress-style-bar"></div><!-- filler to get the styling just right -->
		 <img src="<?php echo compat_get_plugin_url( 'hasloo' ); ?>/themes/core/core-images/gigpress.png" id="music-icon" alt="GigPress" />
		 <h4><?php _e( 'Upcoming Tour Dates', 'hasloo' ); ?></h4>		
			<?php
			    $options = array('scope' => 'upcoming', 'limit' => 10);
			    echo gigpress_shows($options);
			?>
	 </div>
 <?php } ?>
</div>
<!-- #start the hasloo plugin use check -->
<?php hasloo_core_header_check_use(); ?>
<div id="topheadergraphic" align="center"><img src="<?php echo compat_get_plugin_url( 'hasloo' ); ?>/themes/core/core-images/logo.png" id="logo" alt="logo" /></div>